package hu.bme.aut.suchtowers;

/**
 * Created by Bátor on 2014.12.21..
 */
public interface MapClickDelegate {
    public void mapClicked(float x, float y);
}
